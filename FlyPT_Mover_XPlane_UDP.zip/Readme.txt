Mover UDP Plugin for XPlane 11 & 12

This plugin streams data from XPlane 11 and XPlane 12 to Mover via UDP.

Manual Installation:
Locate your XPlane 11 or XPlane 12 installation folder.
Navigate to: Resources/plugins
Copy the MoverUDP folder (including all its contents) into this directory.

Configuration:
The UDP port can be configured in the MoverUDP.cfg file (it should match the port configured in the Mover XPlane source).
You can also set the destination IP address, which is useful when XPlane and Mover are running on different machines.
The top section of the MoverUDP.cfg file contains instructions for customizing the data sent to Mover.

Notes:
This plugin might be compatible with XPlane 10 (not tested).